#include <GL\glew.h>
#include <glm\gtc\type_ptr.hpp>
#include <glm\gtc\matrix_transform.hpp>
#include <cstdio>
#include <cassert>
#include <map>
#include <vector>
#include <iostream>
#include <fstream>
#include <string>

#include <imgui\imgui.h>
#include <imgui\imgui_impl_sdl_gl3.h>

#include "GL_framework.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

///////// fw decl
namespace ImGui {
	void Render();
}
namespace Axis {
void setupAxis();
void cleanupAxis();
void drawAxis();
}
////////////////

namespace RenderVars {
	const float FOV = glm::radians(65.f);
	const float zNear = 1.f;
	const float zFar = 50.f;

	glm::mat4 _projection;
	glm::mat4 _modelView;
	glm::mat4 _MVP;
	glm::mat4 _inv_modelview;
	glm::vec4 _cameraPoint;

	struct prevMouse {
		float lastx, lasty;
		MouseEvent::Button button = MouseEvent::Button::None;
		bool waspressed = false;
	} prevMouse;

	float panv[3] = { 0.f, 0.f, -15.f };
	float rota[2] = { 0.f, 0.f };
}
namespace RV = RenderVars;

void GLResize(int width, int height) {
	glViewport(0, 0, width, height);
	if(height != 0) RV::_projection = glm::perspective(RV::FOV, (float)width / (float)height, RV::zNear, RV::zFar);
	else RV::_projection = glm::perspective(RV::FOV, 0.f, RV::zNear, RV::zFar);
}

void GLmousecb(MouseEvent ev) {
	if(RV::prevMouse.waspressed && RV::prevMouse.button == ev.button) {
		float diffx = ev.posx - RV::prevMouse.lastx;
		float diffy = ev.posy - RV::prevMouse.lasty;
		switch(ev.button) {
		case MouseEvent::Button::Left: // ROTATE
			RV::rota[0] += diffx * 0.005f;
			RV::rota[1] += diffy * 0.005f;
			break;
		case MouseEvent::Button::Right: // MOVE XY
			RV::panv[0] += diffx * 0.03f;
			RV::panv[1] -= diffy * 0.03f;
			break;
		case MouseEvent::Button::Middle: // MOVE Z
			RV::panv[2] += diffy * 0.05f;
			break;
		default: break;
		}
	} else {
		RV::prevMouse.button = ev.button;
		RV::prevMouse.waspressed = true;
	}
	RV::prevMouse.lastx = ev.posx;
	RV::prevMouse.lasty = ev.posy;
}

//////////////////////////////////////////////////
char* readShaderFile(const char* path, int &shader_type) {
	std::string p(path);
	if (p.rfind(".vert") != std::string::npos) shader_type = GL_VERTEX_SHADER;
	else if (p.rfind(".frag") != std::string::npos) shader_type = GL_FRAGMENT_SHADER;
	else if (p.rfind(".geom") != std::string::npos) shader_type = GL_GEOMETRY_SHADER;
	else {
		printf("Shader extension does not correspont to \".vert\", \".frag\" or \".geom\". Shader type can not be identified.");
		return nullptr;
	}

	std::fstream fil(path, std::fstream::in);
	std::string text;
	char buf[256];
	while (!fil.eof()) {
		fil.getline(buf, 256);
		text += buf;
		text += "\n";
	}
	char* shaderCode = new char[text.length() + 1];
	strcpy_s(shaderCode, text.length()+1, text.c_str());
	return shaderCode;
}

void realcompileShader(GLuint shader, const char* shaderStr, GLenum shaderType, const char* name = ""){
	glShaderSource(shader, 1, &shaderStr, NULL);
	glCompileShader(shader);
	GLint res;
	glGetShaderiv(shader, GL_COMPILE_STATUS, &res);
	if (res == GL_FALSE) {
		glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &res);
		char *buff = new char[res];
		glGetShaderInfoLog(shader, res, &res, buff);
		fprintf(stderr, "Error Shader %s: %s", name, buff);
		delete[] buff;
		glDeleteShader(shader);
	}
}
GLuint compileShader(const char* shaderStr, GLenum shaderType, const char* name = "") {
	GLuint shader = glCreateShader(shaderType);
	realcompileShader(shader, shaderStr, shaderType, name);
	return shader;
}
void linkProgram(GLuint program) {
	glLinkProgram(program);
	GLint res;
	glGetProgramiv(program, GL_LINK_STATUS, &res);
	if (res == GL_FALSE) {
		glGetProgramiv(program, GL_INFO_LOG_LENGTH, &res);
		char *buff = new char[res];
		glGetProgramInfoLog(program, res, &res, buff);
		fprintf(stderr, "Error Link: %s", buff);
		delete[] buff;
	}
}

std::map<GLuint, std::tuple<const char*, int>> shader_Map;
std::map<GLuint, std::vector<GLuint>> shader_program_Map;
void reloadShaders() {
	for (auto shader : shader_Map) {
		GLuint sha_id = shader.first;
		const char* sha_path = std::get<0>(shader.second);
		GLuint sha_type = std::get<1>(shader.second);

		int sha_t;
		char* sh_te = readShaderFile(sha_path, sha_t);
		realcompileShader(sha_id, sh_te, sha_type, sh_te);
		delete[] sh_te;

		auto progs = shader_program_Map.find(sha_id)->second;
		for (auto prog : progs) {
			linkProgram(prog);
		}
	}
}
void removeShaders(GLuint shader) {
	shader_Map.erase(shader);
	shader_program_Map.erase(shader);
}

////////////////////////////////////////////////// AXIS
namespace Axis {
GLuint AxisVao;
GLuint AxisVbo[3];
GLuint AxisShader[2];
GLuint AxisProgram;

float AxisVerts[] = {
	0.0, 0.0, 0.0,
	1.0, 0.0, 0.0,
	0.0, 0.0, 0.0,
	0.0, 1.0, 0.0,
	0.0, 0.0, 0.0,
	0.0, 0.0, 1.0
};
float AxisColors[] = {
	1.0, 0.0, 0.0, 1.0,
	1.0, 0.0, 0.0, 1.0,
	0.0, 1.0, 0.0, 1.0,
	0.0, 1.0, 0.0, 1.0,
	0.0, 0.0, 1.0, 1.0,
	0.0, 0.0, 1.0, 1.0
};
GLubyte AxisIdx[] = {
	0, 1,
	2, 3,
	4, 5
};
const char* Axis_vertShader =
"#version 330\n\
in vec3 in_Position;\n\
in vec4 in_Color;\n\
out vec4 vert_color;\n\
uniform mat4 mvpMat;\n\
void main() {\n\
	vert_color = in_Color;\n\
	gl_Position = mvpMat * vec4(in_Position, 1.0);\n\
}";
const char* Axis_fragShader =
"#version 330\n\
in vec4 vert_color;\n\
out vec4 out_Color;\n\
void main() {\n\
	out_Color = vert_color;\n\
}";

void setupAxis() {
	glGenVertexArrays(1, &AxisVao);
	glBindVertexArray(AxisVao);
	glGenBuffers(3, AxisVbo);

	glBindBuffer(GL_ARRAY_BUFFER, AxisVbo[0]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(float) * 24, AxisVerts, GL_STATIC_DRAW);
	glVertexAttribPointer((GLuint)0, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(0);

	glBindBuffer(GL_ARRAY_BUFFER, AxisVbo[1]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(float) * 24, AxisColors, GL_STATIC_DRAW);
	glVertexAttribPointer((GLuint)1, 4, GL_FLOAT, false, 0, 0);
	glEnableVertexAttribArray(1);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, AxisVbo[2]);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(GLubyte) * 6, AxisIdx, GL_STATIC_DRAW);

	glBindVertexArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

	AxisShader[0] = compileShader(Axis_vertShader, GL_VERTEX_SHADER, "AxisVert");
	AxisShader[1] = compileShader(Axis_fragShader, GL_FRAGMENT_SHADER, "AxisFrag");

	AxisProgram = glCreateProgram();
	glAttachShader(AxisProgram, AxisShader[0]);
	glAttachShader(AxisProgram, AxisShader[1]);
	glBindAttribLocation(AxisProgram, 0, "in_Position");
	glBindAttribLocation(AxisProgram, 1, "in_Color");
	linkProgram(AxisProgram);
}
void cleanupAxis() {
	glDeleteBuffers(3, AxisVbo);
	glDeleteVertexArrays(1, &AxisVao);

	glDeleteProgram(AxisProgram);
	glDeleteShader(AxisShader[0]);
	glDeleteShader(AxisShader[1]);
}
void drawAxis() {
	glBindVertexArray(AxisVao);
	glUseProgram(AxisProgram);
	glUniformMatrix4fv(glGetUniformLocation(AxisProgram, "mvpMat"), 1, GL_FALSE, glm::value_ptr(RV::_MVP));
	glDrawElements(GL_LINES, 6, GL_UNSIGNED_BYTE, 0);

	glUseProgram(0);
	glBindVertexArray(0);
}
}

////////////////////////////////////////////////// CUBE
namespace Cube {
GLuint cubeVao;
GLuint cubeVbo[3];
GLuint cubeShaders[3];
GLuint cubeProgram;
glm::mat4 objMat = glm::mat4(1.f);

extern const float halfW = 0.5f;
int numVerts = 24 + 6; // 4 vertex/face * 6 faces + 6 PRIMITIVE RESTART

					   //   4---------7
					   //  /|        /|
					   // / |       / |
					   //5---------6  |
					   //|  0------|--3
					   //| /       | /
					   //|/        |/
					   //1---------2
glm::vec3 verts[] = {
	glm::vec3(-halfW, -halfW, -halfW),
	glm::vec3(-halfW, -halfW,  halfW),
	glm::vec3(halfW, -halfW,  halfW),
	glm::vec3(halfW, -halfW, -halfW),
	glm::vec3(-halfW,  halfW, -halfW),
	glm::vec3(-halfW,  halfW,  halfW),
	glm::vec3(halfW,  halfW,  halfW),
	glm::vec3(halfW,  halfW, -halfW)
};
glm::vec3 norms[] = {
	glm::vec3(0.f, -1.f,  0.f),
	glm::vec3(0.f,  1.f,  0.f),
	glm::vec3(-1.f,  0.f,  0.f),
	glm::vec3(1.f,  0.f,  0.f),
	glm::vec3(0.f,  0.f, -1.f),
	glm::vec3(0.f,  0.f,  1.f)
};

glm::vec3 cubeVerts[] = {
	verts[1], verts[0], verts[2], verts[3],
	verts[5], verts[6], verts[4], verts[7],
	verts[1], verts[5], verts[0], verts[4],
	verts[2], verts[3], verts[6], verts[7],
	verts[0], verts[4], verts[3], verts[7],
	verts[1], verts[2], verts[5], verts[6]
};
glm::vec3 cubeNorms[] = {
	norms[0], norms[0], norms[0], norms[0],
	norms[1], norms[1], norms[1], norms[1],
	norms[2], norms[2], norms[2], norms[2],
	norms[3], norms[3], norms[3], norms[3],
	norms[4], norms[4], norms[4], norms[4],
	norms[5], norms[5], norms[5], norms[5]
};
GLubyte cubeIdx[] = {
	0, 1, 2, 3, UCHAR_MAX,
	4, 5, 6, 7, UCHAR_MAX,
	8, 9, 10, 11, UCHAR_MAX,
	12, 13, 14, 15, UCHAR_MAX,
	16, 17, 18, 19, UCHAR_MAX,
	20, 21, 22, 23, UCHAR_MAX
};

const char* cube_vertShader =
"#version 330\n\
in vec3 in_Position;\n\
in vec3 in_Normal;\n\
out vec4 vert_Normal;\n\
uniform mat4 objMat;\n\
uniform mat4 mv_Mat;\n\
uniform mat4 mvpMat;\n\
void main() {\n\
	gl_Position = mvpMat * objMat * vec4(in_Position, 1.0);\n\
	vert_Normal = mv_Mat * objMat * vec4(in_Normal, 0.0);\n\
}";
const char* cube_geomShader =
"#version 330\n\
layout(triangles) in;\n\
layout(triangle_strip, max_vertices=3) out;\n\
in vec4 vert_Normal[];\n\
out vec4 vert_g_Normal;\n\
void main() {\n\
	gl_Position = gl_in[0].gl_Position; \n\
	vert_g_Normal = vert_Normal[0];\n\
	EmitVertex();\n\
	gl_Position = gl_in[1].gl_Position;\n\
	vert_g_Normal = vert_Normal[1];\n\
	EmitVertex();\n\
	gl_Position = gl_in[2].gl_Position;\n\
	vert_g_Normal = vert_Normal[2];\n\
	EmitVertex();\n\
	EndPrimitive();\n\
}";
const char* cube_fragShader =
"#version 330\n\
in vec4 vert_g_Normal;\n\
out vec4 out_Color;\n\
uniform mat4 mv_Mat;\n\
uniform vec4 color;\n\
void main() {\n\
	out_Color = vec4(color.xyz * dot(vert_g_Normal, mv_Mat*vec4(0.0, 1.0, 0.0, 0.0)) + color.xyz * 0.3, 1.0 );\n\
}";
void setupCube() {
	glGenVertexArrays(1, &cubeVao);
	glBindVertexArray(cubeVao);
	glGenBuffers(3, cubeVbo);

	glBindBuffer(GL_ARRAY_BUFFER, cubeVbo[0]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(cubeVerts), cubeVerts, GL_STATIC_DRAW);
	glVertexAttribPointer((GLuint)0, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(0);

	glBindBuffer(GL_ARRAY_BUFFER, cubeVbo[1]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(cubeNorms), cubeNorms, GL_STATIC_DRAW);
	glVertexAttribPointer((GLuint)1, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(1);

	glPrimitiveRestartIndex(UCHAR_MAX);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, cubeVbo[2]);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(cubeIdx), cubeIdx, GL_STATIC_DRAW);

	glBindVertexArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

	cubeShaders[0] = compileShader(cube_vertShader, GL_VERTEX_SHADER, "cubeVert");
	cubeShaders[1] = compileShader(cube_fragShader, GL_FRAGMENT_SHADER, "cubeFrag");
	cubeShaders[2] = compileShader(cube_geomShader, GL_GEOMETRY_SHADER, "cubeGeom");

	cubeProgram = glCreateProgram();
	glAttachShader(cubeProgram, cubeShaders[0]);
	glAttachShader(cubeProgram, cubeShaders[1]);
	glAttachShader(cubeProgram, cubeShaders[2]);
	glBindAttribLocation(cubeProgram, 0, "in_Position");
	glBindAttribLocation(cubeProgram, 1, "in_Normal");
	linkProgram(cubeProgram);
}
void cleanupCube() {
	glDeleteBuffers(3, cubeVbo);
	glDeleteVertexArrays(1, &cubeVao);

	glDeleteProgram(cubeProgram);
	glDeleteShader(cubeShaders[0]);
	glDeleteShader(cubeShaders[1]);
	glDeleteShader(cubeShaders[2]);
}
void updateCube(const glm::mat4& transform) {
	objMat = transform;
}
void drawCube(float time) {
	glEnable(GL_PRIMITIVE_RESTART);
	glBindVertexArray(cubeVao);
	glUseProgram(cubeProgram);
	glUniformMatrix4fv(glGetUniformLocation(cubeProgram, "mv_Mat"), 1, GL_FALSE, glm::value_ptr(RenderVars::_modelView));
	glUniformMatrix4fv(glGetUniformLocation(cubeProgram, "mvpMat"), 1, GL_FALSE, glm::value_ptr(RenderVars::_MVP));

	glm::vec3 c1_pos = glm::vec3(-2.f, 0.f, 0.f);
	glm::mat4 obj1 = glm::translate(objMat, c1_pos);
	glUniformMatrix4fv(glGetUniformLocation(cubeProgram, "objMat"), 1, GL_FALSE, glm::value_ptr(obj1));
	glUniform4f(glGetUniformLocation(cubeProgram, "color"), 0.1f, 1.f, 1.f, 1.f);
	glDrawElements(GL_TRIANGLE_STRIP, numVerts, GL_UNSIGNED_BYTE, 0);

	//glm::mat4 obj2 = glm::translate(
	//	glm::rotate(
	//		glm::translate(
	//			glm::scale(
	//				glm::translate(objMat, glm::vec3(2.f, sin(time), 0.f)),
	//					glm::vec3(1.f + (sin(time) + 1.f))),
	//			glm::vec3(c1_pos)),
	//		time, glm::vec3(0.f, 1.0f, 0.f)),
	//	glm::vec3(-c1_pos));
	glm::mat4 obj2 = glm::translate(objMat, -c1_pos);
	glUniformMatrix4fv(glGetUniformLocation(cubeProgram, "objMat"), 1, GL_FALSE, glm::value_ptr(obj2));
	glUniform4f(glGetUniformLocation(cubeProgram, "color"), 0.5f*sin(time) + 0.5f, 0.f, 0.f, 1.f);
	glDrawElements(GL_TRIANGLE_STRIP, numVerts, GL_UNSIGNED_BYTE, 0);

	glUseProgram(0);
	glBindVertexArray(0);
	glDisable(GL_PRIMITIVE_RESTART);
}
}

bool loadOBJ(const char* path,
	std::vector<glm::vec3>& out_verts,
	std::vector<glm::vec2>& out_uvs,
	std::vector<glm::vec3>& out_norms) {

	std::vector<glm::vec3> tmp_verts, tmp_norms;
	std::vector<glm::vec2> tmp_uvs;
	glm::vec3 tmp_V;
	glm::vec2 tmp_T;
	glm::vec3 tmp_N;
	std::fstream f(path, std::fstream::in);
	while (!f.eof()) {
		char buff[256];
		f.getline(buff, 256);
		switch (buff[0]) {
		case 'v': {
			switch (buff[1]) {
			case ' ':
				sscanf_s(&buff[2], "%f %f %f\n", &tmp_V.x, &tmp_V.y, &tmp_V.z);
				tmp_verts.push_back(tmp_V);
				break;
			case 't':
				sscanf_s(&buff[2], "%f %f\n", &tmp_T.x, &tmp_T.y);
				tmp_uvs.push_back(tmp_T);
				break;
			case 'n':
				sscanf_s(&buff[2], "%f %f %f\n", &tmp_N.x, &tmp_N.y, &tmp_N.z);
				tmp_norms.push_back(tmp_N);
				break;
			}
			break;
		}
		case 'f': 
			{
			int v_idx[3], t_idx[3], n_idx[3];
			sscanf_s(&buff[2], "%d/%d/%d %d/%d/%d %d/%d/%d\n", &v_idx[0], &t_idx[0], &n_idx[0], &v_idx[1], &t_idx[1], &n_idx[1], &v_idx[2], &t_idx[2], &n_idx[2]);
			out_verts.push_back(tmp_verts[v_idx[0]-1]);
			out_verts.push_back(tmp_verts[v_idx[1]-1]);
			out_verts.push_back(tmp_verts[v_idx[2]-1]);
			out_uvs.push_back(tmp_uvs[t_idx[0]-1]);
			out_uvs.push_back(tmp_uvs[t_idx[1]-1]);
			out_uvs.push_back(tmp_uvs[t_idx[2]-1]);
			out_norms.push_back(tmp_norms[n_idx[0]-1]);
			out_norms.push_back(tmp_norms[n_idx[1]-1]);
			out_norms.push_back(tmp_norms[n_idx[2]-1]);
			}
			break;
		}
	}
	return true;
}

namespace Object {
	GLuint objectVao;
	GLuint objectVbo[3];
	GLuint objectShaders[3];
	GLuint objectProgram;
	GLuint objectTexture;
	glm::mat4 objMat = glm::mat4(1.f);

	void setupObject() {

		std::vector<glm::vec3> verts, norms;
		std::vector<glm::vec2> uvs;
		loadOBJ("4.03.cube.obj", verts, uvs, norms);///

		int x, y, n;
		unsigned char *dat = stbi_load("sqrtke.jpeg", &x, &y, &n, 3);
		glGenTextures(1, &objectTexture);
		glBindTexture(GL_TEXTURE_2D, objectTexture);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, x, y, 0, GL_RGB, GL_UNSIGNED_BYTE, dat);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		stbi_image_free(dat);

		glGenVertexArrays(1, &objectVao);
		glBindVertexArray(objectVao);
		glGenBuffers(3, objectVbo);

		glBindBuffer(GL_ARRAY_BUFFER, objectVbo[0]);
		glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3)*verts.size(), verts.data(), GL_STATIC_DRAW);
		glVertexAttribPointer((GLuint)0, 3, GL_FLOAT, GL_FALSE, 0, 0);
		glEnableVertexAttribArray(0);

		glBindBuffer(GL_ARRAY_BUFFER, objectVbo[1]);
		glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3)*norms.size(), norms.data(), GL_STATIC_DRAW);
		glVertexAttribPointer((GLuint)1, 3, GL_FLOAT, GL_FALSE, 0, 0);
		glEnableVertexAttribArray(1);
		
		glBindBuffer(GL_ARRAY_BUFFER, objectVbo[2]);
		glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec2)*uvs.size(), uvs.data(), GL_STATIC_DRAW);
		glVertexAttribPointer((GLuint)2, 2, GL_FLOAT, GL_FALSE, 0, 0);
		glEnableVertexAttribArray(2);

		glBindVertexArray(0);
		glBindBuffer(GL_ARRAY_BUFFER, 0);

		int sha_type;
		
		char* object_vertShader = readShaderFile("objectShader.vert", sha_type);
		objectShaders[0] = compileShader(object_vertShader, sha_type, "objectShader.vert");
		shader_Map.insert(std::make_pair(objectShaders[0], std::make_tuple("objectShader.vert",sha_type)));
		
		char* object_fragShader = readShaderFile("objectShader.frag", sha_type);
		objectShaders[1] = compileShader(object_fragShader, sha_type, "objectShader.frag");
		shader_Map.insert(std::make_pair(objectShaders[1], std::make_tuple("objectShader.frag", sha_type)));

		char* object_geomShader = readShaderFile("objectShader.geom", sha_type);
		objectShaders[2] = compileShader(object_geomShader, sha_type, "objectShader.geom");
		shader_Map.insert(std::make_pair(objectShaders[2], std::make_tuple("objectShader.geom", sha_type)));

		delete[] object_vertShader;
		delete[] object_fragShader;
		delete[] object_geomShader;

		objectProgram = glCreateProgram();
		glAttachShader(objectProgram, objectShaders[0]);
		glAttachShader(objectProgram, objectShaders[1]);
		glAttachShader(objectProgram, objectShaders[2]);
		glBindAttribLocation(objectProgram, 0, "in_Position");
		glBindAttribLocation(objectProgram, 1, "in_Normal");
		glBindAttribLocation(objectProgram, 2, "in_UVs");
		linkProgram(objectProgram);
		auto it = shader_program_Map.find(objectShaders[0]);
		if (it != shader_program_Map.end()) {
			it->second.push_back(objectProgram);
		} else {
			std::vector<GLuint> v; v.push_back(objectProgram);
			shader_program_Map.insert(std::make_pair(objectShaders[0], v));
		}
		auto it2 = shader_program_Map.find(objectShaders[1]);
		if (it2 != shader_program_Map.end()) {
			it2->second.push_back(objectProgram);
		} else {
			std::vector<GLuint> v; v.push_back(objectProgram);
			shader_program_Map.insert(std::make_pair(objectShaders[1], v));
		}
		auto it3 = shader_program_Map.find(objectShaders[2]);
		if (it3 != shader_program_Map.end()) {
			it3->second.push_back(objectProgram);
		}
		else {
			std::vector<GLuint> v; v.push_back(objectProgram);
			shader_program_Map.insert(std::make_pair(objectShaders[2], v));
		}
	}
	void cleanupObject() {
		glDeleteTextures(1, &objectTexture);
		glDeleteBuffers(3, objectVbo);
		glDeleteVertexArrays(1, &objectVao);

		glDeleteProgram(objectProgram);
		glDeleteShader(objectShaders[0]);
		glDeleteShader(objectShaders[1]);
	}
	void drawObject(float time) {
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, objectTexture);

		glBindVertexArray(objectVao);
		glUseProgram(objectProgram);
		glUniform1d(glGetUniformLocation(objectProgram, "tex"), 0);
		glUniformMatrix4fv(glGetUniformLocation(objectProgram, "mv_Mat"), 1, GL_FALSE, glm::value_ptr(RenderVars::_modelView));
		glUniformMatrix4fv(glGetUniformLocation(objectProgram, "projMat"), 1, GL_FALSE, glm::value_ptr(RenderVars::_projection));
		glUniformMatrix4fv(glGetUniformLocation(objectProgram, "mvpMat"), 1, GL_FALSE, glm::value_ptr(RenderVars::_MVP));
		glUniformMatrix4fv(glGetUniformLocation(objectProgram, "objMat"), 1, GL_FALSE, glm::value_ptr(objMat));
		glUniform1f(glGetUniformLocation(objectProgram, "time"), time);
		glUniform4f(glGetUniformLocation(objectProgram, "color"), 0.1f, 1.f, 1.f, 1.f);
		glDrawArrays(GL_TRIANGLES, 0, 12*3);

		glUseProgram(0);
		glBindVertexArray(0);
	}
}


float aspect_ratio;

void GLinit(int width, int height) {
	glViewport(0, 0, width, height);
	glClearColor(0.2f, 0.2f, 0.2f, 1.f);
	glClearDepth(1.f);
	glDepthFunc(GL_LEQUAL);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);

	aspect_ratio = (float)width / (float)height;
	RV::_projection = glm::perspective(RV::FOV, aspect_ratio, RV::zNear, RV::zFar);

	// Setup shaders & geometry
	Axis::setupAxis();
	//Cube::setupCube();
	Object::setupObject();
	
	/////////////////////////////////////////////////////TODO
	// Do your init code here
	// ...
	// ...
	/////////////////////////////////////////////////////////
}

void GLcleanup() {
	Axis::cleanupAxis();
	//Cube::cleanupCube();
	Object::cleanupObject();
	/////////////////////////////////////////////////////TODO
	// Do your cleanup code here
	// ...
	// ...
	/////////////////////////////////////////////////////////
}

void GLrender(float dt) {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	static float accum = 0.f;
	accum += dt;
	if (accum > glm::two_pi<float>()) accum = 0.f;

	RV::_modelView = glm::mat4(1.f);
	RV::_modelView = glm::translate(RV::_modelView, glm::vec3(RV::panv[0], RV::panv[1], RV::panv[2]));
	RV::_modelView = glm::rotate(RV::_modelView, RV::rota[1], glm::vec3(1.f, 0.f, 0.f));
	RV::_modelView = glm::rotate(RV::_modelView, RV::rota[0], glm::vec3(0.f, 1.f, 0.f));

	RV::_MVP = RV::_projection * RV::_modelView;

	Axis::drawAxis();
	//Cube::drawCube(accum);
	Object::drawObject(accum);

	//float llx = RV::prevMouse.lastx;
	//float lly = (600 - RV::prevMouse.lasty);
	//glm::vec3 unp = glm::unProject(glm::vec3(llx, lly, 0.0), RV::_modelView, RV::_projection, glm::vec4(0, 0, 800, 600));
	//std::cout << unp.x << " " << unp.y << " " << unp.z << std::endl;
	/////////////////////////////////////////////////////TODO
	// Do your render code here
	// ...
	// ...
	/////////////////////////////////////////////////////////

	ImGui::Render();
}

void GUI() {
	bool show = true;
	ImGui::Begin("Physics Parameters", &show, 0);

	{
		ImGui::Text("Application average %.3f ms/frame (%.1f FPS)", 1000.0f / ImGui::GetIO().Framerate, ImGui::GetIO().Framerate);

		if (ImGui::Button("Reload shaders!")) {
			reloadShaders();
		}
		/////////////////////////////////////////////////////TODO
		// Do your GUI code here....
		// ...
		// ...
		// ...
		/////////////////////////////////////////////////////////
	}
	// .........................

	ImGui::End();

	// Example code -- ImGui test window. Most of the sample code is in ImGui::ShowTestWindow()
	bool show_test_window = false;
	if (show_test_window) {
		ImGui::SetNextWindowPos(ImVec2(650, 20), ImGuiSetCond_FirstUseEver);
		ImGui::ShowTestWindow(&show_test_window);
	}
}